// OOP.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Student.h"
#include "Teacher.h"
#include <vector>

int main() {

	std::cout << sizeof(Human) << std::endl;//48 bytes
	std::cout << sizeof(Student) << std::endl;//56 bytes
	std::cout << sizeof(Teacher) << std::endl;//56 bytes

	std::vector<Human*> school;
	school.push_back(new Student("Noel", 19, 4.0f));
	school.push_back(new Teacher("Cody", 19, "C++", 207));

	for (int i = 0; i < school.size(); i++) {

		school[i]->Work();
		if (dynamic_cast<Student*>(school[i])) {
			std::cout << dynamic_cast<Student*>(school[i])->GetGPA() << std::endl;
		}

	
		//((Student*)(school[i]))->setGPA(3.5f);
		//std::cout << school[i]->GetName() << std::endl;
	}

	//Student student1("Amia", 20, 3.9f);
	Student* student = new Student("Amia", 20, 3.9f);

	std::cout << student->GetName() << std::endl;
	std::cout << student->GetAge() << std::endl;

	delete student;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
