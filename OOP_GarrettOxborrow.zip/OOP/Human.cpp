#include "Human.h"

int Human::m_count = 0; // Initialize static member variable outside the class
const float Human::m_tax = 0.0825f;

void func() {
	std::cout << "Funky\n";
}

void Human::SetAge(age_t age) {
	if (age > 0 && age < 120) {
		m_age = age;
	}
	else {
		std::cout << "Invalid age" << std::endl;
	}
}